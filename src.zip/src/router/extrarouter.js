export default {
    '/video-interrogation': '/moduledoctor-video-lists', // 住院管理> 临床监护 >患者管理> 患者详情
    '/user-detail': '/modulehealthy-index' // 住院管理> 临床监护 >患者管理> 患者详情
}
