/**
 * 配置文件
 */
export default {
    // clientId: 'sino-jh', // 客户端id
    // clientSecret: 'sino-jh-platform' // 客户端密钥
    clientId: 'sino', // 客户端id
    clientSecret: 'sino_secret' // 客户端密钥
}
