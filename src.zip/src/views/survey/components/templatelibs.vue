<template>
    <div class="components-libs-wrapper scrollbar-wrapper">
        <p class="page-title text-center">模版库</p>
    </div>
</template>

<script>
export default {
    data() {
        return {
        }
    },
    methods: {
    }
}
</script>

<style lang="scss" scoped>
.components-libs-wrapper {
    user-select: none;
    height: 100%;
    padding-top: 60px;
    position: relative;
}

.page-title {
    position: absolute;
    top: 16px;
    left: 0;
    width: 100%;
    text-align: center;
    font-weight: bold;
    font-size: 16px;
}

</style>
