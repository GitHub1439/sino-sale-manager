export default {
    sdkAppId: 1400411969,
    SECRETKEY:
        'e6d917fb507579fe45001bce079a1c41570a55e8b1abc17952cf4a05028b293b',
    userSig:
        // eslint-disable-next-line max-len
        'eJw1TssKgkAU-ZfZGnJnHOchtCpoofTAQHAXziTX8IGZSdG-N2jtzpvzJuck9e3UYW9JJIArgNWsjbYnEWE*kIXfze3SdWhIRDkAp1QLvThobDPgFefCljINiisWMBGClMzB-wKWLlCLaqpwk2t2Gqssfnq0yLk9vlIjldfsH*WhyJJ4105tuf4VB6zdORpqGQjJhfh8ASr-M4k_'
}
